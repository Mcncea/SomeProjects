This project using junit and surefire for convenient test

Run "mvn test" for surfire automatic test