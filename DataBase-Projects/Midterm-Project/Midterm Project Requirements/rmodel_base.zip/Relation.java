package RModel;

import java.util.ArrayList;
import java.util.Collection;

public class Relation {

	private String name;
	private ArrayList<Tuple> tuples;
	private ArrayList<Attribute> attributes;
	
	public Relation(String name, Collection<Attribute> attrs) {
		
		this.name = name;
		this.attributes = new ArrayList<Attribute>(attrs); 
		this.tuples = new ArrayList<Tuple>();
	}
	
	public Relation(String name, Collection<Attribute> attrs, Collection<Tuple> tuples) {
		
		this.name = name;
		this.attributes = new ArrayList<Attribute>(attrs); 
		this.tuples = new ArrayList<>(tuples);
		
	}
	
	public void insertTuple() {
		
	}
	
	public void deleteTuple() {
		
	}
	
	public void updateTuple() {
		
	}
	
	public void printRelation() {
//		System.out.println(Arrays.toString(attributes.toArray()));
		String str = "RELATION: " + this.name + "\n";
		for( Attribute attr : attributes ) {
			str += attr.getName() + "\t";
		}
		str += "\n";
		for (Tuple tuple : this.tuples) {
			for(Attribute attr: attributes ) {
				Object val = tuple.getAttribute(attr.getName());
				str += val + "\t";
			}
			str += "\n";
		}
		System.out.println(str);
	}
     
}
